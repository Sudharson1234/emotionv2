from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash
from datetime import datetime
import urllib

app = Flask(__name__)

password = 'sudharson123'
encoded_password = urllib.parse.quote(password)
app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql://root:{encoded_password}@localhost:3306/database_tourism'
app.config['SECRET_KEY'] = 'sudharson123'
db = SQLAlchemy(app)

class User(db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False)
    age = db.Column(db.Integer, nullable=False)
    gender = db.Column(db.String(10), nullable=False)
    date_of_birth = db.Column(db.Date, nullable=False)
    address = db.Column(db.String(200), nullable=False)
    password = db.Column(db.String(255), nullable=False)  # Password column size updated

@app.route('/')
def form():
    return render_template('capstone.html')

@app.route('/submit', methods=['POST'])
def submit_form():
    name = request.form['name']
    email = request.form['email']
    age = request.form['age']
    gender = request.form['gender']
    date_of_birth = request.form['date_of_birth']
    address = request.form['address']
    password = request.form['password']
    
    # Hash the password before storing it in the database
    hashed_password = generate_password_hash(password, method='pbkdf2:sha256')
    
    # Create a new user instance
    new_user = User(
        name=name,
        email=email,
        age=age,
        gender=gender,
        date_of_birth=datetime.strptime(date_of_birth, '%Y-%m-%d').date(),
        address=address,
        password=hashed_password
    )
    
    # Add the new user to the session and commit to the database
    db.session.add(new_user)
    db.session.commit()

    return redirect(url_for('home'))

@app.route('/home')
def home():
    return render_template('submit.html')

if __name__ == '__main__':
    app.run(debug=True)
